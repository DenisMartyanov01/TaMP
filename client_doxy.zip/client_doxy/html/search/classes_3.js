var searchData=
[
  ['singleton_5fclient_0',['Singleton_client',['../class_singleton__client.html',1,'']]],
  ['singleton_5fdestroyer_1',['Singleton_destroyer',['../class_singleton__destroyer.html',1,'']]],
  ['statistics_2',['Statistics',['../class_statistics.html',1,'']]]
];
