var searchData=
[
  ['singleton_5fdestroyer_0',['Singleton_destroyer',['../class_singleton__client.html#a193320bf03e6204c414837a1d9a2e283',1,'Singleton_client']]]
];
