var searchData=
[
  ['p_5finstance_0',['p_instance',['../class_singleton__destroyer.html#ab887b0c43e43cf8311ba679e89cb6c62',1,'Singleton_destroyer::p_instance'],['../class_singleton__client.html#a5dbf2b5e9b62535f49a65d0cfd38266c',1,'Singleton_client::p_instance']]]
];
