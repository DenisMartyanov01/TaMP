var searchData=
[
  ['send_5fmsg_5fto_5fserver_0',['send_msg_to_server',['../class_singleton__client.html#af016f99d72d0024e2ea834618ce393fd',1,'Singleton_client']]],
  ['singleton_5fclient_1',['Singleton_client',['../class_singleton__client.html#a2e883f8c237fa75a69b47d3e3b681755',1,'Singleton_client::Singleton_client(QObject *parent=nullptr)'],['../class_singleton__client.html#a8fdbf9660e293061c5f20bcc88ce125b',1,'Singleton_client::Singleton_client(Singleton_client &amp;)=delete']]],
  ['slot_5fclient_5fdisconnect_2',['slot_client_disconnect',['../class_singleton__client.html#aa22babee18b1a023e6f4d46ea8792de8',1,'Singleton_client']]],
  ['slot_5fserver_5fread_3',['slot_server_read',['../class_singleton__client.html#a8e1a02ff2fb1a657af1e5dad4f3e3eea',1,'Singleton_client']]],
  ['slotclientdisconnected_4',['slotClientDisconnected',['../class_my_tcp_server.html#a3e040c49dbefd65b9a58ab662fc9f7a2',1,'MyTcpServer']]],
  ['slotnewconnection_5',['slotNewConnection',['../class_my_tcp_server.html#a0ba7316ffe1a26c57fabde9e74b6c8dc',1,'MyTcpServer']]],
  ['slotserverread_6',['slotServerRead',['../class_my_tcp_server.html#ab4a64d2eab985d723090963f5c8a2882',1,'MyTcpServer']]],
  ['statistics_7',['Statistics',['../class_statistics.html#a9b074d3400e74d785e24957f573bbf7e',1,'Statistics']]]
];
