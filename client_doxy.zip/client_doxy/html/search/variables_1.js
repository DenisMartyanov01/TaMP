var searchData=
[
  ['instance_0',['instance',['../class_my_d_b_destroyer.html#ac5a853559262fce7bfaedf5ffb66f3a5',1,'MyDBDestroyer::instance'],['../class_my_d_b.html#a134125344d04849cddb8bf369eb41296',1,'MyDB::instance']]]
];
