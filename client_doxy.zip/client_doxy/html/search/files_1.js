var searchData=
[
  ['functions_5ffor_5fclient_2ecpp_0',['functions_for_client.cpp',['../functions__for__client_8cpp.html',1,'']]],
  ['functions_5ffor_5fclient_2eh_1',['functions_for_client.h',['../functions__for__client_8h.html',1,'']]],
  ['functionsforserver_2ecpp_2',['functionsforserver.cpp',['../functionsforserver_8cpp.html',1,'']]],
  ['functionsforserver_2eh_3',['functionsforserver.h',['../functionsforserver_8h.html',1,'']]]
];
