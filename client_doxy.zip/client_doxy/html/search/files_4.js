var searchData=
[
  ['singleton_5fclient_2ecpp_0',['singleton_client.cpp',['../singleton__client_8cpp.html',1,'']]],
  ['singleton_5fclient_2eh_1',['singleton_client.h',['../singleton__client_8h.html',1,'']]],
  ['statistics_2ecpp_2',['statistics.cpp',['../statistics_8cpp.html',1,'']]],
  ['statistics_2eh_3',['statistics.h',['../statistics_8h.html',1,'']]]
];
