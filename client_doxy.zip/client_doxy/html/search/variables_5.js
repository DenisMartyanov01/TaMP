var searchData=
[
  ['task1_0',['task1',['../class_main_window.html#ad9442c99f343b564fedd89feaa7dc23e',1,'MainWindow']]],
  ['task2_1',['task2',['../class_main_window.html#a91eb7df5d9b0b1daf9fab0c92521f6d2',1,'MainWindow']]],
  ['task3_2',['task3',['../class_main_window.html#a00649a68df5fa4026feddab35b02ff82',1,'MainWindow']]]
];
