var searchData=
[
  ['parsing_0',['parsing',['../functionsforserver_8cpp.html#ac9c69440740d7a40040d85eecff036c8',1,'parsing(QString Request):&#160;functionsforserver.cpp'],['../functionsforserver_8h.html#a84a7a3dce07db2cbefa4118664f562c9',1,'parsing(QString):&#160;functionsforserver.cpp']]]
];
