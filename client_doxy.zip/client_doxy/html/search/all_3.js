var searchData=
[
  ['functions_5ffor_5fclient_0',['functions_for_client',['../classfunctions__for__client.html',1,'functions_for_client'],['../classfunctions__for__client.html#a1b96206434af3137fc5112f884adb972',1,'functions_for_client::functions_for_client()']]],
  ['functions_5ffor_5fclient_2ecpp_1',['functions_for_client.cpp',['../functions__for__client_8cpp.html',1,'']]],
  ['functions_5ffor_5fclient_2eh_2',['functions_for_client.h',['../functions__for__client_8h.html',1,'']]],
  ['functionsforserver_2ecpp_3',['functionsforserver.cpp',['../functionsforserver_8cpp.html',1,'']]],
  ['functionsforserver_2eh_4',['functionsforserver.h',['../functionsforserver_8h.html',1,'']]]
];
