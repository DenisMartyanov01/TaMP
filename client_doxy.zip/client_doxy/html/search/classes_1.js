var searchData=
[
  ['functions_5ffor_5fclient_0',['functions_for_client',['../classfunctions__for__client.html',1,'']]]
];
