var searchData=
[
  ['task1_0',['Task1',['../class_task1.html',1,'']]],
  ['task2_1',['Task2',['../class_task2.html',1,'']]],
  ['task3_2',['Task3',['../class_task3.html',1,'']]]
];
