var indexSectionsWithContent =
{
  0: "acdfgilmopqrstu~",
  1: "afmst",
  2: "u",
  3: "afmrst",
  4: "acfgilmopqrst~",
  5: "dimpstu",
  6: "ms"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Friends"
};

