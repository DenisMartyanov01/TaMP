var searchData=
[
  ['statistics_0',['statistics',['../class_main_window.html#a9858b5a1762ca22af61d72ba48ebf599',1,'MainWindow']]]
];
