var searchData=
[
  ['p_5finstance_0',['p_instance',['../class_singleton__destroyer.html#ab887b0c43e43cf8311ba679e89cb6c62',1,'Singleton_destroyer::p_instance'],['../class_singleton__client.html#a5dbf2b5e9b62535f49a65d0cfd38266c',1,'Singleton_client::p_instance']]],
  ['parsing_1',['parsing',['../functionsforserver_8cpp.html#ac9c69440740d7a40040d85eecff036c8',1,'parsing(QString Request):&#160;functionsforserver.cpp'],['../functionsforserver_8h.html#a84a7a3dce07db2cbefa4118664f562c9',1,'parsing(QString):&#160;functionsforserver.cpp']]]
];
