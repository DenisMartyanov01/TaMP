var searchData=
[
  ['checkvalidemail_0',['checkValidEmail',['../functionsforserver_8cpp.html#ab0fc6bd68121113dff282e44d5eaca27',1,'functionsforserver.cpp']]],
  ['createtable_1',['createTable',['../class_my_d_b.html#a667c802bceb5691a003f4f881e7eb163',1,'MyDB']]]
];
