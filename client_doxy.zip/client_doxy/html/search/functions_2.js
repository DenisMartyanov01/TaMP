var searchData=
[
  ['functions_5ffor_5fclient_0',['functions_for_client',['../classfunctions__for__client.html#a1b96206434af3137fc5112f884adb972',1,'functions_for_client']]]
];
