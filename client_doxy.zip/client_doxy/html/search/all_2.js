var searchData=
[
  ['db_0',['db',['../class_my_d_b.html#a4bbafd1f56ed0c6d9c2f28f908565437',1,'MyDB']]],
  ['destroyer_1',['destroyer',['../class_my_d_b.html#a763721062a287f6a605200e3647d3a88',1,'MyDB::destroyer'],['../class_singleton__client.html#aaf22dd92526a20b2be733217af0b7cd5',1,'Singleton_client::destroyer']]]
];
