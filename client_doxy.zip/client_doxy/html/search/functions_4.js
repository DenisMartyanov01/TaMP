var searchData=
[
  ['initialize_0',['initialize',['../class_my_d_b_destroyer.html#a39d877d05ba70b92c144c1def6a5c3e7',1,'MyDBDestroyer::initialize()'],['../class_singleton__destroyer.html#ad781044abeb31b8f5a61dea4a1c586de',1,'Singleton_destroyer::initialize()']]],
  ['is_5fauth_1',['is_auth',['../classauth__reg.html#a0a95a37837d893856c7a24d85ce5f8fe',1,'auth_reg::is_auth()'],['../classfunctions__for__client.html#ac83da3f341f372ab782cbc6935b56cc0',1,'functions_for_client::is_auth()']]]
];
