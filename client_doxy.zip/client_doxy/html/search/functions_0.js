var searchData=
[
  ['auth_0',['auth',['../functionsforserver_8cpp.html#ae258e0deae1a8eab2553d8bab0bb8891',1,'auth(QString Login, QString Password):&#160;functionsforserver.cpp'],['../functionsforserver_8h.html#a9718449e1044fc97ced3b6dc779c2407',1,'auth(QString, QString):&#160;functionsforserver.cpp']]],
  ['auth_5freg_1',['auth_reg',['../classauth__reg.html#a45ff7c2226acb2168fce6492e5fa1ae2',1,'auth_reg']]]
];
