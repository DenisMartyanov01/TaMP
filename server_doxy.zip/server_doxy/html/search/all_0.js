var searchData=
[
  ['allshortestpaths_0',['allShortestPaths',['../functionsforserver_8cpp.html#abe7faa5efacd3f7f53162f3ab7e328e2',1,'allShortestPaths(const QString &amp;Login, const std::vector&lt; std::vector&lt; int &gt; &gt; &amp;graph):&#160;functionsforserver.cpp'],['../functionsforserver_8h.html#a82d5a35713b6222218ae912466317fad',1,'allShortestPaths(const QString &amp;, const std::vector&lt; std::vector&lt; int &gt; &gt; &amp;):&#160;functionsforserver.cpp']]],
  ['auth_1',['auth',['../functionsforserver_8cpp.html#ae258e0deae1a8eab2553d8bab0bb8891',1,'auth(QString Login, QString Password):&#160;functionsforserver.cpp'],['../functionsforserver_8h.html#a9718449e1044fc97ced3b6dc779c2407',1,'auth(QString, QString):&#160;functionsforserver.cpp']]],
  ['authanswer_2',['AuthAnswer',['../functionsforserver_8cpp.html#a22bc2eaa5fdcf92e3a3168f935742e54',1,'functionsforserver.cpp']]]
];
