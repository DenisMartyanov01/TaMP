var searchData=
[
  ['lookallstat_0',['lookallstat',['../functionsforserver_8cpp.html#a4d7f6597fea754f2377e28bf69ca8764',1,'lookallstat(QString Login, QString Password):&#160;functionsforserver.cpp'],['../functionsforserver_8h.html#ad7d86ea0550a10f572746b35fdd808f8',1,'lookallstat(QString, QString):&#160;functionsforserver.cpp']]],
  ['lookmystat_1',['lookmystat',['../functionsforserver_8cpp.html#aeedd8f2eb3f8bd887039bafd0cf7a71c',1,'lookmystat(QString Login, QString Password):&#160;functionsforserver.cpp'],['../functionsforserver_8h.html#a4a92c33a1261e9370c355a5ffec63ac0',1,'lookmystat(QString, QString):&#160;functionsforserver.cpp']]]
];
