var searchData=
[
  ['checkauth_0',['checkAuth',['../functionsforserver_8cpp.html#a2596a1e6084a61f58621d284e9766ce8',1,'functionsforserver.cpp']]],
  ['checkvalidemail_1',['checkValidEmail',['../functionsforserver_8cpp.html#ab0fc6bd68121113dff282e44d5eaca27',1,'functionsforserver.cpp']]],
  ['createtable_2',['createTable',['../class_my_d_b.html#a667c802bceb5691a003f4f881e7eb163',1,'MyDB']]]
];
