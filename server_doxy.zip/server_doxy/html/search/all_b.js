var searchData=
[
  ['querytodb_0',['queryToDB',['../class_my_d_b.html#ac74d00ab91668e76eb97d505cf9fd267',1,'MyDB']]]
];
