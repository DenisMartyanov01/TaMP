var searchData=
[
  ['id_5fconnection_0',['id_connection',['../class_my_client.html#a676bf876d96f353b5c70c83be28da1b7',1,'MyClient']]],
  ['initialize_1',['initialize',['../class_my_d_b_destroyer.html#a39d877d05ba70b92c144c1def6a5c3e7',1,'MyDBDestroyer']]],
  ['instance_2',['instance',['../class_my_d_b_destroyer.html#ac5a853559262fce7bfaedf5ffb66f3a5',1,'MyDBDestroyer::instance'],['../class_my_d_b.html#a134125344d04849cddb8bf369eb41296',1,'MyDB::instance']]],
  ['is_5fauth_3',['is_auth',['../class_my_client.html#a6e953773fb270dcfa9444777d0023e74',1,'MyClient']]]
];
