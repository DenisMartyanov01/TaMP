var searchData=
[
  ['initialize_0',['initialize',['../class_my_d_b_destroyer.html#a39d877d05ba70b92c144c1def6a5c3e7',1,'MyDBDestroyer']]],
  ['is_5fauth_1',['is_auth',['../class_my_client.html#a6e953773fb270dcfa9444777d0023e74',1,'MyClient']]]
];
