var searchData=
[
  ['operator_3d_0',['operator=',['../class_my_d_b.html#afa5b740b84f156cc271e332a698ed47e',1,'MyDB']]]
];
