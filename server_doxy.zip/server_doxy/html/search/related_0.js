var searchData=
[
  ['mydbdestroyer_0',['MyDBDestroyer',['../class_my_d_b.html#ac41d8e44277f31a2f0036c7a0cbf4ae2',1,'MyDB']]]
];
