var searchData=
[
  ['readme_2emd_0',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['reg_1',['reg',['../functionsforserver_8cpp.html#a377854965baca37d623afc1baa54a3a5',1,'reg(QString Login, QString Password, QString Email):&#160;functionsforserver.cpp'],['../functionsforserver_8h.html#a8f7a6d95131df69089548d3bee1fc03a',1,'reg(QString, QString, QString):&#160;functionsforserver.cpp']]]
];
