var searchData=
[
  ['id_5fconnection_0',['id_connection',['../class_my_client.html#a676bf876d96f353b5c70c83be28da1b7',1,'MyClient']]],
  ['instance_1',['instance',['../class_my_d_b_destroyer.html#ac5a853559262fce7bfaedf5ffb66f3a5',1,'MyDBDestroyer::instance'],['../class_my_d_b.html#a134125344d04849cddb8bf369eb41296',1,'MyDB::instance']]]
];
