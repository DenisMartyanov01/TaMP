var searchData=
[
  ['checkauth_0',['checkAuth',['../functionsforserver_8cpp.html#a2596a1e6084a61f58621d284e9766ce8',1,'functionsforserver.cpp']]]
];
