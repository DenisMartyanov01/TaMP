var searchData=
[
  ['get_5finstance_0',['get_instance',['../class_my_d_b.html#a3e743ee268a10bc6b0ef3c03723424f8',1,'MyDB']]]
];
