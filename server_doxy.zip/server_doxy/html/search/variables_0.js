var searchData=
[
  ['authanswer_0',['AuthAnswer',['../functionsforserver_8cpp.html#a22bc2eaa5fdcf92e3a3168f935742e54',1,'functionsforserver.cpp']]]
];
