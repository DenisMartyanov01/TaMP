var searchData=
[
  ['mtcpserver_0',['mTcpServer',['../class_my_tcp_server.html#a7d854875e1e02887023ec9aac1a1542c',1,'MyTcpServer']]],
  ['mtcpsocket_1',['mTcpSocket',['../class_my_client.html#a87f0dd22c1112ddc04bd0e90af4bb01c',1,'MyClient::mTcpSocket'],['../class_my_tcp_server.html#a6ef1d4ed0de8643969ef96b7145cc91e',1,'MyTcpServer::mTcpSocket']]]
];
